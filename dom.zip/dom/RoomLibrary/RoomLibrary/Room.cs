﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RoomLibrary
{
    public class Room
    {
        double roomLength; // длина комнаты
        double roomWidth; // ширина комнаты
        public double RoomLength
        {
            get { return roomLength; }
            set { roomLength = value; }
        }
        public double RoomWidth
        {
            get { return roomWidth; }
            set { roomWidth = value; }
        }
        /// <summary>
        /// метод вычисляет периметр комнаты
        /// </summary>
        /// <returns>возвращает значение периметра</returns>
        public double   RoomPerimeter()
        {
            return 2 * (roomLength + roomWidth);
        }
        /// <summary>
        /// метод вычисляе площадь комнаты
        /// </summary>
        /// <returns>возвращает значение площади</returns>
        public double RoomArea()
        {
            return roomLength * roomWidth;
        }
        /// <summary>
        /// метод вычисляет число квадратных метров на одного человека
        /// </summary>
        /// <param name="np"></param>
        /// <returns>возвращает число квадратных метров</returns>
        public double PersonArea(int np)
        {
            return RoomArea() / np;

        }
        /// <summary>
        /// информация о комнате
        /// </summary>
        /// <returns>возвращает строку</returns>
        public string Info()
        {
            return "комната площадью" + RoomArea() + "кв.м";
        }
    }
    public class LivingRoom : Room
    {
        int numWin; //число окон
        public int NumWin
        { get { return numWin; } set { numWin = value; } }
        /// <summary>
        /// Метод возвращает информацию о комнате
        /// </summary>
        /// <returns>возвращается строка с информацией</returns>
        public new string Info()
        {
            return "Жилая комната площадью" + RoomArea() + "кв.м"; 
        }
    }
    public class Office : Room
    {
        int numSockets; //
        public int NumSockets
        {  get { return numSockets;  } set { numSockets = value; } }
        /// <summary>
        /// Возвращает максимально возможное число рабочих мест 
        /// </summary>
        /// <returns>Возвращается число мест</returns>

       
        public int NumWorkplaces()
        {
            int num = Convert.ToInt32(Math.Truncate(RoomArea() / 4.5));
            return Math.Min(num, numSockets);   
        }
        /// <summary>
        /// Метод возвращает информацию об офисе
        /// </summary>
        /// <returns>Возвращается строка с информацией</returns>
        public new string Info()
        {
            return "Офис на " + NumWorkplaces() + " рабочих мест";
        }
    }
}
