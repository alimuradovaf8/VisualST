﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace banki1
{
    using banki1.classes;
    
    internal class Program
    {

        Console.WriteLine(account.GetAccountHistory());
    }
}
