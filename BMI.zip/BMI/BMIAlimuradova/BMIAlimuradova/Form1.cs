﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BMIAlimuradova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            double rost = Convert.ToInt32(textBox1.Text);
            double rost_M = rost / 100;
            double ves = Convert.ToInt32(textBox2.Text);
          
            int BMI = Convert.ToInt32(ves / (rost_M * rost_M));
            label15.Text = BMI.ToString();



            if (BMI < 10) {
                trackBar1.Value = 10;
                label15.Text = "Недостаточный вес";
            }
            else if (BMI < 18.5 && BMI >= 10) {
                trackBar1.Value = Convert.ToInt32(BMI);
                label15.Text = "Недостаточный вес";
            }
            else if (BMI >= 18.5 && BMI <= 24.9) {
                trackBar1.Value = Convert.ToInt32(BMI);
                label15.Text = "Здоровый вес"; 
            }
            else if(BMI <= 30 && BMI > 24.9){
                trackBar1.Value = Convert.ToInt32(BMI);
                label15.Text = "Избыточный"; 
            }
            else if (BMI > 30 && BMI < 40) {
                trackBar1.Value = Convert.ToInt32(BMI);
                label15.Text = "Ожирение";

            }

         
            
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox1.Image;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox2.Image;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
    }
}
