﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace textAF
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            this.label1.Text = "Текстовый редактор";
            this.label3.Text = "Версия {0}";
            this.label2.Text = "Алимурадова Фатима Алимбеговна"; // AssemblyCopyright;
            this.label4.Text = "КМПО";
            this.textBox1.Text = ""; //AssemblyDescription;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
